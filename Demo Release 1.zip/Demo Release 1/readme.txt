  ______                    _   _             _  ___             
 |  ____|                  | | | |           | |/ (_)            
 | |__ ___  _ __ __ _  ___ | |_| |_ ___ _ __ | ' / _ _ __   __ _ 
 |  __/ _ \| '__/ _` |/ _ \| __| __/ _ \ '_ \|  < | | '_ \ / _` |
 | | | (_) | | | (_| | (_) | |_| ||  __/ | | | . \| | | | | (_| |
 |_|  \___/|_|  \__, |\___/ \__|\__\___|_| |_|_|\_\_|_| |_|\__, |
                 __/ |                                      __/ |
                |___/                                      |___/ 

Welcome to Forgotten King, my singleminded obsession over the past few months.

This readme serves as a mini-tutorial of sorts, documenting the systems and
controls you will encounter while playing the game. Hitting [?] in game will open
a similar help menu.

Forgotten King is a procedurally generated roguelike dungeon crawler, that tasks
the player with venturing through a large dungeon to slay a final boss, before
returning a victory item taken from its corpse to the surface. Everything that you
do, from exploring, gathering powerful equipment and slaying monsters for those
sweet experience points, serves to make your character more powerful to succeed in
your quest.

-----------------------------------------------------------------------------------
CONTROLS:
-----------------------------------------------------------------------------------
Menu Controls:
Arrow keys to scroll if the menu is scrollable
Character keys to select specific menu options
[esc] to exit

Mouse Controls:
While Forgotten King is intended to be played with a keyboard, there is a small
amount of mouse support with a lot more to be implemented in the future. Mouse
controls are currently pretty buggy in inventory screens if they are navigated to
via the keyboard, however opening the inventory through the mouse button seems to
fix this bug until you close the game. Why this is happening, I'm not sure.
 - Start a new game and select a character
 - Right click enemies or items lying around to inspect them
 - Open various menus from the menu bar at the bottom right hand of the screen
 - Left click enemies nearby to attack them if you are in range
 - Left click yourself to pick up items you are standing over, or traverse a
   staircase.
 - Currently most menus and targeting screens do not have mouse support

Movement Controls:
Arrow Keys, NumPad or vi (hjklyubn) keys to move
Bump into enemies to melee attack them
[.] to wait a turn to rest
[R] to Rest and recuperate for a time
[<] or [>] to move up or down a staircase
[C] to Close an open door next to you

Inventory Controls:
[i] to view your Inventory
[g] to Grab items
[w] to Wear/Wield equipment
[d] to Drop an item
[t] to Throw an item
[f] to Fire an equipped ranged weapon
[q] to Quaff a potion
[r] to Read a book or scroll
[tab] to swap to your last used weapon

Magic Commands
[c] to Cast a memorized spell
[m] to Meditate on spell points

Misc Controls:
[s] to view your (very basic) character Stats
[x] to eXamine your surroundings
[p] to open the Perk menu
[space] to pick up items or use staircases



-----------------------------------------------------------------------------------
COMBAT:
-----------------------------------------------------------------------------------
As Forgotten King is a dungeon crawling roguelike, there are many combat
encounters the player will have to fight through.

Combat is simple enough, bump into enemies to make a melee attack against them.
Clearly, equipped weapons make your melee attacks more potent, however the Unarmed
Training perk (see Perks) make your unarmed strikes far more powerful than they
normally would be.

If you have a ranged weapon equipped along with suitable ammo quivered 
(a shortbow + arrows) you can [f]ire at enemies in range.

You can throw items such as darts, rocks, or potions (or really anything) at
enemies with the [t]hrow command.

If you have spells memorized (see Magic) you can [c]ast spells
to deal damage or apply effects to enemies in range.

If you have learned any Abilities (see Abilities) you can [a]ctivate them, making
yourself more powerful (Raging) or giving you alternative forms of attack to bring
down your foes (Reach Attack.)

Enemies with a little yellow dot at the bottom left corner of their character icon
signifies that they are currently equipped with a weapon, making them more powerful.
You can e[x]amine them and the game will tell you what weapon they currently have
equipped. If you hit [enter] while examining them, a menu will open that shows a
brief description of the enemy, along with any perks or abilities they have.

You should always examine powerful enemies to make sure you know what youre up
against.

Additionally, each creature has a movement delay and an attack delay. Whenever they
take one of these actions, their next turn is delayed for that long. For example,
the average delay is 10. If a creature (a bat) has a movement delay of 5, they will
move two times for every one time you move. Creatures with reduced attack delay,
typically wielding daggers, will make an additional attack every so often opposed
to slower creatures. There are effects that both slow and hasten you, and you
should be wary of those enemies that are quick as their damage quickly multiplies
on itself.

As death in Forgotten King is permanent, my best advice is to not die. However, the
current demo version is short enough that death is only a minor setback, sending
you back to the title screen and letting you select a new Character to begin again.



-----------------------------------------------------------------------------------
COMBAT MATH:
-----------------------------------------------------------------------------------
For the most part, attacks are made against a targets evasion. When making an
attack, you roll two d10s, and then add your attack modifier to it. This number is
made against the target's evasion, and is skewed towards 10+attack, making high
evasion slightly more powerful than it appears.

If the attack hits, it deals one of nine damage types. Six of these types are
magical (see Magic) and three of them are Physical. 
 - Slashing
 - Piercing
 - Crushing
If the attack deals physical damage, it is reduced by up to 80% by the targets
armor (potentially more if you have certain perks. The fighter reduces incoming
damage by 88% for example.) This means that 20% of all damage is unaffected by any
amount of armor.

Finally, the target can have resistances to that damage type. If they do, the
total damage is reduced by an amount, and sometimes even healing the intended target
rather than damaging them. In particular:
Resistance:	Damage Taken:
	-1	150%
	 0 	100%
	 1	66%
	 2	33%
	 3	0%
	 4	-33%

Concerning critical hits:
Every attack has a guaranteed 5% chance to fail, and a critical chance equal to
your accuracy. Critical hits automatically hit, and ignore armor and resistances.
Creatures relying on high armor should beware of enemies with high crit chance 
(such as the Lizard Shadowblade.)



-----------------------------------------------------------------------------------
ATTRIBUTES AND STATS:
-----------------------------------------------------------------------------------
In Forgotten King, each creature in the game has a set of three attributes that
each correspond to two stats. A utility/defensive stat and an offensive stat.
A more detailed run down of each stat can be seen in game through the help menu, 
or by viewing your [s]tats and hitting [enter].

Strength:
 - Toughness: Makes your character harder to kill by increasing their hit points
              and rate of regeneration.
 - Brawn: Makes your character more potent in melee combat, granting increased
          attack and damage while attacking.

Dexterity:
 - Agility: Increases your evasion and slightly increases your movement speed.
 - Accuracy: Makes your characters ranged attacks more powerful. If you have a
             weapon with the Light tag equipped, you use your Accuracy instead of
             Brawn to determine melee attacks.

Intelligence: (For more detail, see Magic)
 - Will: Increases your mana, available spell levels, and makes you more resistant
         to magical effects.
 - Spellcasting: Increases your spell points and makes magical attacks more
                 powerful.

Stats are designed in such a way that they all can be useful for every character.
A focused spellcaster might want to allocate a point to Toughness every now and
then, in order to increase their health and survivability. A focused fighter may
want to spend points in Will, to avoid being affected by the many negative effects
found in the dungeon, or in Agility in order to increase their evasion. This does
not even mention the amount of ways you can create hybrid characters, such as a
Spear Wielding character that is trained in Air magic so they can stun powerful
enemies before attacking them at a range with their spear. There is nothing to
stop the Fighter Character from picking up an early Book of Vitality and a ring
of Spellcasting before they put some points into Intelligence in order to learn
the powerful Regeneration and Heroism spells.

Attributes are quite simple. Each attribute increases both of its corresponding
stats by 1.



-----------------------------------------------------------------------------------
PROGRESSION:
-----------------------------------------------------------------------------------
Player progression is decided through experience points gained from slaying
enemies. Upon level up, the player gains 1 Stat or Attribute point (Attribute points
are gained every 3 levels) to spend. These can be spent through viewing your
[s]tats, and then hitting [enter] to level up. A notification will appear in the
top left corner if you have unspent points.

Every fourth level you gain 1 Perk point. These can be spent on perks that enhance
your characters build and playstyle. See Perks for more info on how these work.



-----------------------------------------------------------------------------------
INVENTORY:
-----------------------------------------------------------------------------------
Of course, progression is also intended through the acquirement of more powerful
equipment to increase your combat stats over time. You have 9 inventory slots.
 - Weapon
 - Off-Hand
 - Armor
 - Ring
 - Amulet
 - Boots
 - Cloak
 - Gloves
 - Head
Additionally, some equipment will give you other stat bonuses, detailed by viewing
the item in the [i]nventory screen (hit [enter] when it is selected.)

Currently, there are very basic pieces of equipment, that mostly increase your
Armor or attack strength. However most weapons are intended to be interesting with
various tags (the Spear allows reach attacks, the dagger attacks quickly and is
a Light weapon) that can really complement your playstyle and build. 



-----------------------------------------------------------------------------------
PERKS:
-----------------------------------------------------------------------------------
Every four levels you get a Perk point to spend. The [p]erks menu lists every perk
alongside any prerequisites it has. To spend a perk point, navigate to one you
want and hit enter. There are currently 17 perks implemented in game, however the
current demo version is only long enough to unlock a single one (after the free
perk you get upon selecting a character) so choose wisely. Perk points can be held
for as long as you feel is necessary, if you need more stats to unlock some one
you need.

Perks hopefully represent powerful bonuses that complement builds that you work
towards. For example, if you plan on having a melee oriented class that focuses
on the Accuracy stat to use light weapons, it may be important to select the
Improved Critical perk (increases critical chance by 10%) to get through heavy
armor and resistances. If you already have that perk (if you selected the Ranger
character at the beginning of the game) you may want to select the Deadly Critical
perk, that increases your critical damage by your dexterity-accuracy. 

Alternatively, if you find yourself being surrounded often as a melee fighter. You
might be interested in the Knockback All perk, that grants you the ability to
knockback all enemies that are adjacent to you so you can reposition to avoid
taking so many hits. This would also be useful to give you an edge while running
from a powerful enemy.



-----------------------------------------------------------------------------------
ABILITIES:
-----------------------------------------------------------------------------------
There are only a few abilities currently implemented in Forgotten King as of this
demo, however the framework is there to add far more in the future. The abilities
menu is accessed through [a], which will list off all abilities you currently know
along with their cooldown. By activating an ability (selecting it with a character
or the arrow keys, and then hitting [enter]) you will open up a targeting menu to
select what the ability affects. Then you must wait for the cooldown to end before
you can activate it again.

Abilities offer many powerful ways to customize your build. The Berserker character
starts with the rage ability, temporarily increasing your strength before needing
time to recover. Spears allow you to attack enemies up to two tiles away and you 
can unlock the ability to knock back all enemies adjacent to you through a perk.



-----------------------------------------------------------------------------------
MAGIC:
-----------------------------------------------------------------------------------
Magic is a system that attempts to give the player lots of freedom in what schools
of magic they specialize in, while making the Intelligence stats no more useful or
complicated than the others. This results in a highly modular system that rewards
prioritizing spell schools while being able to adapt your character build to
spells that you find laying around the dungeon.

There are a few resources you need to keep track of:
 - Spell Points, along with how they are allocated
 - Spell Levels and the spells you already have memorized
 - Mana, so you can cast the spells you plan on using

To start, you need to have a spellbook in your inventory. The Elementalist character
starts with the Book of Kindling. From there, you can [r]ead the book, to memorize
spells and add them to your spell list. Every spell has a level (shown by type:level)
In order to memorize a spell, you need to have available spell levels to fit that
spell. Spell levels are gained by level and Will. For example, to memorize the
powerful level 3 spell Fireball, you need to have 3 spell levels available.

Once spells are memorized, those spell levels are added and your future number of
spells you can add are constrained.

In order to cast spells, you need to allocate spell points. This can be done by
[m]editating in the magic menu. Spell points are gained by your Spellcasting stat.
You can move spell points around between the different schools of magic, however
every change that you make takes some amount of time so you cannot meditate while
enemies are present. In order to cast spells, you need to have a number of spell
points allocated to that spells school equal to its level. This means in order
to cast Fireball, you need to have 3 points allocated to the Fire school. Putting
points in magic schools also makes the spells of that school more potent, so an
experienced Fire user will have more powerful Embers than a user dabbling in fire.

This means that your character can easily switch between different schools of magic
to adapt to different spells that you find, while being constrained by the number
of spell levels you can memorize. You may want to focus of a broad amount of
different spells and effects, such as being able to cast Shocking Touch, Chill, and
Cure Poison. Or you may want to focus on casting a single large spell (again, such
as Fireball) while abandoning the utility that other spell schools grant. It is
fully up to you to decide.



-----------------------------------------------------------------------------------
KNOWN BUGS AND PROBLEMS
-----------------------------------------------------------------------------------
 - The AI of creatures is pretty bad (they sometimes go brain dead when changing
   targets from you to an ally)
 - Being shocked while stunned essentially doubles the stun duration if you shock
   them every turn do to how both of these effects are handled
 - Picking up a bunch of stuff at once (such as 100 rocks for example) can exceed
   your carrying capacity



-----------------------------------------------------------------------------------
THANK YOU!
-----------------------------------------------------------------------------------
I hope that this documentation helps. I would love to see any and all feedback and
suggestions in the comments. This game is a living project, and the breadthe of
content that is planned for the future is rather immense and the most important
thing is that the game is fun to play.
Itch.io Page:  https://urist2112.itch.io/forgotten-king
GameJolt Page: https://gamejolt.com/games/forgotten_king/551737

Credits:
 - The amazing DawnHack tileset by DragonDePlatino, palette by DawnBringer.
 - All game icons before slight modification by Lorc, Delapouite & contributors.
 - Music, title screen and both ending screens by Elephant Toothpaste
   https://soundcloud.com/user-385599278